import React from "react";
import "./styles.css"; // Import the CSS file

const Card = ({ color, title, imageSrc, content, price }) => (
  <div className="card">
    <div className="img-box">
      <img src={imageSrc} alt={`Image for ${title}`} />
    </div>
    <div className="content">
      <h2 className={`text-${color} font-bold text-2xl `}>{title}</h2>
      <p className="text-gray-900 font-bold mt-10 price">${price}</p>
      <p className="text-gray-700">{content}</p>
      <a
        href={`/singleProductPage/${title}`}
        className={`btn-${color} font-semibold py-3 px-6 mt-4 inline-block text-white no-underline`}
      >
        View Details
      </a>
    </div>
  </div>
);

const AllProducts = () => (
  <div className="body bg-gray-800 min-h-screen flex justify-center items-center">
    <h1 className="text-center text-3xl font-bold mb-8">All Products</h1>
    <div className="container flex justify-center items-center flex-wrap gap-8 md:gap-4 py-16 px-8 md:p-16">
      <Card
        color="teal-500"
        title="Product 1"
        imageSrc="https://cdn11.bigcommerce.com/s-7exlzlf13h/images/stencil/960w/products/144/506/Clarett_4Pre-frontelevated-2400-2400__18357.1676372081.png"
        content="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto, hic? Magnam eum error saepe doloribus corrupti repellat quisquam alias doloremque!"
        price={19.99} // Replace with the actual price
      />
      <Card
        color="pink-500"
        title="Product 2"
        imageSrc="https://cdn11.bigcommerce.com/s-7exlzlf13h/images/stencil/960w/products/305/787/scarlett-solo-studio-group-2400-2400__30297.1693324508.png?c=1"
        content="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto, hic? Magnam eum error saepe doloribus corrupti repellat quisquam alias doloremque!"
        price={19.99} // Replace with the actual price
      />
      <Card
        color="blue-500"
        title="Product 3"
        imageSrc="https://cdn11.bigcommerce.com/s-7exlzlf13h/images/stencil/640w/products/246/397/solo-studio-lead-2400-2400__13972.1675698184.png?c=1"
        content="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto, hic? Magnam eum error saepe doloribus corrupti repellat quisquam alias doloremque!"
        price={19.99} // Replace with the actual price
      />
      <Card
        color="teal-500"
        title="Product 4"
        imageSrc="https://cdn11.bigcommerce.com/s-7exlzlf13h/images/stencil/960w/products/144/506/Clarett_4Pre-frontelevated-2400-2400__18357.1676372081.png"
        content="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto, hic? Magnam eum error saepe doloribus corrupti repellat quisquam alias doloremque!"
        price={19.99} // Replace with the actual price
      />
      <Card
        color="pink-500"
        title="Product 5"
        imageSrc="https://cdn11.bigcommerce.com/s-7exlzlf13h/images/stencil/960w/products/305/787/scarlett-solo-studio-group-2400-2400__30297.1693324508.png?c=1"
        content="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto, hic? Magnam eum error saepe doloribus corrupti repellat quisquam alias doloremque!"
        price={19.99} // Replace with the actual price
      />
      <Card
        color="blue-500"
        title="Product 6"
        imageSrc="https://cdn11.bigcommerce.com/s-7exlzlf13h/images/stencil/640w/products/246/397/solo-studio-lead-2400-2400__13972.1675698184.png?c=1"
        content="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto, hic? Magnam eum error saepe doloribus corrupti repellat quisquam alias doloremque!"
        price={19.99} // Replace with the actual price
      />
      <Card
        color="blue-500"
        title="Product 7"
        imageSrc="https://cdn11.bigcommerce.com/s-7exlzlf13h/images/stencil/640w/products/293/779/RedNet-PreCle-front-elevated-2400-x-2400__13042.1689338727.png?c=1"
        content="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto, hic? Magnam eum error saepe doloribus corrupti repellat quisquam alias doloremque!"
        price={19.99} // Replace with the actual price
      />
      <Card
        color="blue-500"
        title="Product 8"
        imageSrc="https://cdn11.bigcommerce.com/s-7exlzlf13h/images/stencil/640w/products/145/526/Clarett_OctoPre-frontelevated-2400-2400__59799.1676374979.png?c=1"
        content="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto, hic? Magnam eum error saepe doloribus corrupti repellat quisquam alias doloremque!"
        price={19.99} // Replace with the actual price
      />
      <Card
        color="blue-500"
        title="Product 9"
        imageSrc="https://cdn11.bigcommerce.com/s-7exlzlf13h/images/stencil/640w/products/131/537/vocaster-one-studio-knolling-2400-2400__45909.1676905760.png?c=1"
        content="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto, hic? Magnam eum error saepe doloribus corrupti repellat quisquam alias doloremque!"
        price={19.99} // Replace with the actual price
      />
    </div>
  </div>
);

export default AllProducts;
